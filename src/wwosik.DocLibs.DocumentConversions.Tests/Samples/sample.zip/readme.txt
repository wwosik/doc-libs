A plain ZIP archive, not an Office document.
